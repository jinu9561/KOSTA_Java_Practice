package mvc.view;

public class FailView {
	 /**
     * 실패  관련된 메세지 출력 
     * @param message
     */
    public static void errorMessage(String message) {
         System.out.println(message+"\n");
    }
}
